package Interfaces;

public interface Mensagem {
		
	void msg();
	
	
		
	

}
